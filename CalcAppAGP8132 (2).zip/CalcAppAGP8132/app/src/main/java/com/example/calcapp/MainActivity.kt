package com.example.calcapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var insectsInput: EditText
    private lateinit var catsInput: EditText
    private lateinit var birdsInput: EditText
    private lateinit var calcButton: Button
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        insectsInput = findViewById(R.id.insects_input)
        catsInput = findViewById(R.id.cats_input)
        birdsInput = findViewById(R.id.birds_input)
        calcButton = findViewById(R.id.calc_button)
        resultText = findViewById(R.id.result_text)

        calcButton.setOnClickListener {
            calculateLegs()
        }
    }

    private fun calculateLegs() {
        val insects = insectsInput.text.toString().toIntOrNull() ?: 0
        val cats = catsInput.text.toString().toIntOrNull() ?: 0
        val birds = birdsInput.text.toString().toIntOrNull() ?: 0

        val totalLegs = insects * 6 + cats * 4 + birds * 2

        resultText.text = "Total legs: $totalLegs"
    }
}
